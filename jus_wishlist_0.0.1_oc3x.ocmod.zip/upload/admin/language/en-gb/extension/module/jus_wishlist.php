<?php
// Heading
$_['heading_title']    = 'Wishlist (jus wishlist v0.0.1)';

$_['text_extension']    = 'Extensions';
$_['text_success']      = 'You have modified module!';
$_['text_edit']         = 'Edit module';

// Entry
$_['entry_status']      = 'Status';

// Error
$_['error_permission']  = 'You do not have permission to modify module!';
