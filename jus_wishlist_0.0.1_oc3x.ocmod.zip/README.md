# jus_wishlist - module for OpenCart 3.x

It makes it possible to show Wishlist for not logged users.

